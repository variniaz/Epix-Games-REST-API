
const multer = require('multer');
const upload = multer();

module.exports = upload.single('image');